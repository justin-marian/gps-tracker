Readme Tema 2 SI 2024-2025
-------------------------------------------------------------------------------
Justin-Marian POPESCU, 343C2
-------------------------------------------------------------------------------

Configurare RootFS, Kernel, Overlay si App-Daemon GPS
(Scuze ca este prea mult... Dar numai asa puteam sa explic intr-un mod complex ce am facut ~90 de linii)

Root Filesystem (RootFS)
RootFS-ul generat este de tip rootfs.ext4 si a fost creat utilizand Buildroot, ultima versiune de pe GitHub, pentru platforma Raspberry Pi 3B (bcm2837-rpi-3-b).
Ca punct de plecare, am folosit configuratia oficiala raspberrypi3_64_defconfig, pe care am extins-o cu setari personalizate pentru a implementa cerintele proiectului.
RootFS-ul final are o dimensiune de 256 MB si contine toate componentele necesare pentru rularea serviciilor.
Pachete si Setari Esentiale
Pentru a asigura functionalitatea proiectului, au fost adaugate urmatoarele pachete:
Avahi-daemon: suport pentru mDNS, permitand accesul la sistem prin hostname-ul tema2.local si parola tema2.
Python 3 si pip: necesare pentru rularea aplicatiei HTTP si a daemon-ului.
Flask: framework utilizat pentru implementarea serverului web.
OpenSSH si AutoSSH: pentru acces remote si forwardare porturi.
DHCP Client: configurat pentru obtinerea automata a adresei IP pe interfata eth0.
Overlay si Structura
Overlay-ul include fisiere suplimentare si configuratii personalizate, dupa cum urmeaza:
Directorul etc:
init.d: Numerele 68 si 70 au fost alese pentru a evita conflictele cu alte scripturi de initializare deja existente in directorul /etc/init.d, astfel pornesc sigure, fara sa fie interferente cu alte servicii.
passwd, shadow: configuratii pentru autentificare, parola criptata tema2 cu MD5.
ssh: configuratii OpenSSH.
udev: reguli pentru gestionarea dispozitivelor, in subdirectorul rules se afla `mama_mea.rules` care contine reguli pt consistenta a interfetei de retea eth0, a.i toate scripturile si serviciile care depind de eth0 sa functioneze corect.
Evitarea posibilelor conflicte cu alte interfețe sau nume implicite atribuite de sistem.
Directorul opt:
gps-daemon: script pentru colectarea si prelucrarea datelor GPS in format NMEA (GGA si ZDA).
gps-server: server web Flask pentru afisarea datelor GPS in timp real.
templates: contine fisierul index.html pentru interfata vizuala.
Directorul tmp:
Director temporar in care se creeaza un fisier .json ce contine, la fiecare secunda se scrie in el datele GPS procesate de daemon gps-daemon.py, iar applicatia gps-server.py le foloseste pt afisare in browser, http://<IPv4>:8888.
Backup Config File:
In directorul arm/ am inclus un fisier backup denumit config_tema2.txt, care pastreaza configurarile kernel-ului personalizat. Acestea au fost adaptate pentru platforma Broadcom, fisierul a fost creat manual si completat automat de build-ul de la buildroot.
Pentru a genera fisierele Device Tree Blob (DTB) necesare pentru platforma bcm2837-rpi-3-b, am utilizat comanda `make dtbs` din directorul `linux-custom`. Acest proces a fost efectuat manual initial, pana cand am identificat optiunea de automatizare in Buildroot, care permite generarea automata a fisierelor DTB in timpul build-ului.

Kernel Personalizat
Am utilizat kernel-ul v6.12, descarcat de pe site-ul oficial al proiectului Linux (https://github.com/torvalds/linux/), folosind tag-ul verificat pentru aceasta versiune. Configurarile principale includ:
Activarea optiunii pentru utilizarea unui kernel personalizat si dezactivarea functiei auto version (setat -si-justin-marian.popescu).
Setarea locatiei arhivei kernel-ului in format tar.xz.
Adaugarea hash-ului SHA256 al arhivei in fisierul linux.hash pentru a asigura integritatea descarcarii.
Configurarea detaliata a kernel-ului prin linux-menuconfig, ajustand parametrii necesari pentru a indeplini cerintele proiectului, inclusiv pentru suportul USB si senzorul FTDI FT232H.
Suport Adaugat in Kernel
Kernel-ul personalizat include suport extins pentru componentele esentiale ale proiectului, cum ar fi:
Serial Devices: activat pentru comunicarea cu dispozitivele seriale, esential pentru colectarea datelor GPS.
Character Devices: suport pentru dispozitive de tip caracter.
Input Devices: activat pentru conectivitatea cu periferice.
USB Support: configurat pentru a permite utilizarea dispozitivelor USB:
USB Networking (USBNET): pentru gestionarea conexiunilor de retea prin USB.
FTDI USB Serial Converter: necesar pentru comunicarea cu senzorii GPS conectati prin USB.
Driver FTDI pentru GPS: configurat pentru recoltarea si prelucrarea datelor GPS de pe dispozitivul serial.
Functionalitati Extinse
Prin configurarea kernel-ului si a sistemului, s-au adaugat urmatoarele functionalitati:
Gestionarea dinamica a dispozitivelor prin udev, permitand detectarea si configurarea automata a interfetelor seriale si USB.
Acces remote securizat prin OpenSSH, precum si suport pentru forwardarea conexiunilor.
Setari pentru configurarea automata a adresei IP folosind clientul DHCP pe interfata eth0.
Suport pentru aplicatii bazate pe Python, inclusiv serverul web implementat cu Flask.
Optiuni Suplimentare Configurate in Kernel
Pe langa suportul necesar pentru proiect, in kernel au ramas activate si alte optiuni care nu au fost folosite direct, dar care ar putea fi utile in scenarii extinse:
IPv4/IPv6/TCP/Bluetooth/... Support: pentru conectivitate retea robusta, activat implicit, desi neutilizat in tema.

Modificari in Makefile si launch-tema2.sh – Structura si Path-uri
Dupa finalizarea procesului de build utilizand comanda make -j$(nproc), am identificat locatiile exacte ale fisierelor generate (DTB, kernel si rootfs). 
DTB: localizat in ../buildroot/output/build/linux-custom/arch/arm64/boot/dts/broadcom/.
Kernel: localizat in ../buildroot/output/build/linux-custom/arch/arm64/boot/.
RootFS: localizat in ../buildroot/output/images/
Aceste path-uri au fost adaugate in Makefile si launch-tema2.sh pentru a asigura rularea corecta a sistemului.
Schimbari in launch-tema2.sh
Actualizarea fisierelor de boot: Am configurat utilizarea vmlinuz-tema2 in locul vmlinuz-test pentru rulare:
KERNEL_FILE="vmlinuz-tema2"
Modificarea consolei pentru testare: Am schimbat setarea console=ttyS0 in console=ttyAMA0 pentru a asigura compatibilitatea cu kernel-ul utilizat:
_KERNEL_CONSOLE="console=ttyAMA0 console=ttyS1"
Am modificat dispozitivul de root din mmcblk0p2 in mmcblk0 pentru a se potrivi cu structura imaginii generate pt card SD:
ROOTDEV="mmcblk0"

Script-urile Python au reprezentat partea mai `simpla` a temei, fiind utilizate pentru colectarea si prelucrarea datelor GPS, precum si pentru implementarea serverului web. Acestea includ:
1. gps-daemon.py: Colecteaza si prelucreaza datele GPS, salvandu-le intr-un fisier JSON partajat.
Colectarea datelor GPS: Citeste datele GPS in format NMEA (cum ar fi $GPGGA, $GPZDA, $GPGLL, etc.) de pe portul serial utilizand biblioteca serial.
Prelucrarea datelor: Transforma datele brute NMEA intr-un format JSON structurat.
Include functii pentru a converti coordonatele geografice din format NMEA in format decimal si pentru a transforma timpul UTC in format ISO 8601.
Salvarea datelor: Salveaza informatiile GPS prelucrate intr-un fisier JSON local, situat incadrul directorului /tmp/gps_data.json, actualizat periodic (implicit la fiecare secunda).
Logare: Mesajele de logare sunt scrise in fisierul /tmp/gps_daemon.log, urmarind erorile si activitatea scriptului.
2. gps-server.py: Serveste fisierul index.html si expune datele GPS prin intermediul unui API REST.
Un server web simplu: Foloseste biblioteca Flask pentru a expune o interfata web care afiseaza datele GPS procesate.
Endpointuri API: /api/gps: Returneaza datele GPS ca JSON. /: Serveste o interfata web bazata pe fisierul index.html.
Citirea datelor GPS: Preia informatiile in timp real din fisierul JSON generat de gps-daemon.py.
Logare: Evenimentele si erorile sunt inregistrate in fisierul /tmp/gps_server.log pentru depanare.
3. index.html: Aceste fisiere colaboreaza pentru a oferi o solutie completa care colecteaza, prelucreaza si afiseaza intr-un mod grafic datele GPS.
Acest fisier HTML ofera o interfata grafica prietenoasa utilizatorului pentru prezentarea datelor GPS: 
Afisarea datelor GPS: Coordonatele geografice (latitudine si longitudine). Altitudinea.
Informatii despre sateliti (numar de sateliti, tipul fixului GPS, etc.). Ora si data UTC. 
Hartile interactive: Foloseste Google Maps pentru a afisa locatia curenta pe o harta interactiva.
Include suport pentru Street View, permitand utilizatorilor sa vizualizeze locurile in format panoramic.
Actualizare in timp real: Informatiile afisate pe pagina sunt actualizate la fiecare 500 ms folosind JavaScript, prin interogarea endpointului /api/gps.
